# Smart Health Hub

A comprehensive healthcare interoperability platform providing a centralized, secure, and intelligent directory services hub with advanced deployment capabilities.

## Setup Instructions (GitHub Import)

When importing this project from GitHub to Replit, follow these steps:

1. After the import completes, run the startup script:
   ```
   ./start.sh
   ```
   
   This script will:
   - Replace the package.json with a GitHub-compatible version
   - Install all dependencies
   - Build the project
   - Start the server using the CommonJS-compatible server file

2. Once the server starts, your application will be available in the Replit Webview.

## Technologies

- TypeScript/Node.js microservices architecture
- FHIR R4 fully compatible service integration
- PostgreSQL with dynamic service table management
- Drizzle ORM for advanced model relationship management
- Containerized microservice deployment
- Tailwind CSS for responsive UI
