#!/bin/bash
# Smart Health Hub Startup Script

# Use GitHub-compatible package.json
if [ -f "package.json.github" ]; then
  echo "Using GitHub compatible package.json..."
  cp package.json.github package.json
fi

# Install dependencies
echo "Installing dependencies..."
npm install

# Build the project
echo "Building project..."
npm run build

# Start the server
echo "Starting server..."
node server/index.cjs
